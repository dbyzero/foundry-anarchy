import { SRABaseCharacterSheet } from "./base-character-sheet.js";

export class SRACharacterSheet extends SRABaseCharacterSheet{


}