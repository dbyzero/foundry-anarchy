
export class SRACharacter extends Actor {

  prepareData() {
    super.prepareData();
  }
}